<html>
<head>
<meta http-equiv="Content-Type" content="texthtml; charset=utf-8" />
<link rel="stylesheet" href="style.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="mine.js"></script>
</head>
<body>
<h3>DEMO apibonus (use immitation api from api.25one.com.ua/api_bonus.php)</h3>	
<div class="request" class="table">
<form name="form_request" class="form_request">

<div class="table_row">
<div class="table_cell">	
<select name="selectapinumber" class="selectapinumber">
<option id="0">--Select api-item and enter parameters--</option>
<option id="1" value="TID=761/Level=2/Name=Level 2/NextLevelPoints=100/ConfirmPoints=50/Coef=0.3">1.Add/Edit loyalty levels</option>
<option id="2" value="TID=94/Level=1">2.Delete loyalty level</option>
<option id="3" value="TID=8/Level=3">3.Get loyalty level or levels list</option>
<option id="4" value="...">4.Add/Edit bonus</option>
<option id="5" value="...">5.Get bonus data</option>
<option id="6" value="...">6.Get bonuses list</option>
<option id="7" value="...">7.Select/Deselect bonus</option>
<option id="8" value="...">8.Stats bonuses</option>
<option id="9" value="...">9.Cancel bonus to user</option>
<option id="10" value="...">10.Close bonuses</option>
<option id="11" value="...">11.Bonuses block balance by users</option>
<option id="12" value="...">12.Bonus history by user</option>
<option id="13" value="...">13.Delete bonus</option>
<option id="14" value="...">14.Add/Edit loyalty record</option>
<option id="15" value="...">15.Get loyalty recod</option>
<option id="16" value="...">16.Remove loyalty recod</option>
<option id="17" value="...">17.Update loyalty balance</option>
<option id="18" value="...">18.Register events</option>
<option id="19" value="...">19.Add/Edit store item</option>
<option id="20" value="...">20.Change item status</option>
<option id="21" value="...">21.Change item sort order in list</option>
<option id="22" value="...">22.Delete store item</option>
<option id="23" value="...">23.Add/Edit store category</option>
<option id="24" value="...">24.Change category status</option>
<option id="25" value="...">25.Change category sort order in list</option>
<option id="26" value="...">26.Delete store category</option>
<option id="27" value="...">27.Relate store item to category</option>
<option id="28" value="...">28.Get store items and categories lists</option>
<option id="29" value="...">29.Order store item</option>
<option id="30" value="...">30.Get orders list</option>
<option id="31" value="...">31.Store order</option>
<option id="32" value="...">32.Get loyalty requests</option>
<option id="33" value="...">33.Check status loyalty request</option>
<option id="34" value="...">34.Add/Edit tournament</option>
<option id="35" value="...">35.Get tournament data</option>
<option id="36" value="...">36.Get tournaments list</option>
<option id="37" value="...">37.Select/Deselect or Cancel tournament</option>
<option id="38" value="...">38.Delete tournament</option>
<option id="39" value="...">39.User tournaments history</option>
<option id="40" value="...">40.Cancel tournament</option>
<option id="41" value="...">41.Tournament widgets</option>
<option id="42" value="...">42.Check tournament/bonus promocode validity</option>
<option id="43" value="...">43.Get tournament/bonus codes batch list</option>
<option id="44" value="...">44.Gnerate tournament/bonus codes</option>
<option id="45" value="...">45.Tournament/bonus direct codes save</option>
<option id="46" value="...">46.Get Tournament/bonus codes</option>
<option id="47" value="...">47.Delete tournament/bonus codes</option>
</select>	
</div>
<div class="table_cell">
<input type="text" name="textapinumber" class="textapinumber" value="" size="75" placeholder="example TID=777/IDUser=55 ..." /> 
</div>	
</div>

</form>
</div>
<hr>
<div class="answer">
</div>
</body>
</html>
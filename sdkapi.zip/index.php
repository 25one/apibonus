<html>
<head>
<meta http-equiv="Content-Type" content="texthtml; charset=utf-8" />
<link rel="stylesheet" href="style.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="mine.js"></script>
</head>
<body>
<h3>DEMO apibonus (use immitation api from api.25one.com.ua/api_bonus.php)</h3>	
<div class="request" class="table">
<form name="form_request" class="form_request">

<div class="table_row">
<div class="table_cell">	
<select name="selectapinumber" class="selectapinumber">
<option value="0">--Select api-item and enter parameters--</option>
<option value="1" id="TID=761/Level=2/Name=Level 2/NextLevelPoints=100/ConfirmPoints=50/Coef=0.3">1.Add/Edit loyalty levels</option>
<option value="2" id="TID=94/Level=1">2.Delete loyalty level</option>
<option value="3" id="TID=8/Level=3">3.Get loyalty level or levels list</option>
<option value="4" id="...">4.Add/Edit bonus</option>
<option value="5" id="...">5.Get bonus data</option>
<option value="6" id="...">6.Get bonuses list</option>
<option value="7">7.Select/Deselect bonus</option>
<option value="8">8.Stats bonuses</option>
<option value="9">9.Cancel bonus to user</option>
<option value="10">10.Close bonuses</option>
<option value="11">11.Bonuses block balance by users</option>
<option value="12">12.Bonus history by user</option>
<option value="13">13.Delete bonus</option>
<option value="14">14.Add/Edit loyalty record</option>
<option value="15">15.Get loyalty recod</option>
<option value="16">16.Remove loyalty recod</option>
<option value="17">17.Update loyalty balance/option>
<option value="18">18.Register events</option>
<option value="19">19.Add/Edit store item</option>
<option value="20">20.Change item status</option>
<option value="21">21.Change item sort order in list</option>
<option value="22">22.Delete store item</option>
<option value="23">23.Add/Edit store category</option>
<option value="24">24.Change category status</option>
<option value="25">25.Change category sort order in list</option>
<option value="26">26.Delete store category</option>
<option value="27">27.Relate store item to category</option>
<option value="28">28.Get store items and categories lists</option>
<option value="29">29.Order store item</option>
<option value="30">30.Get orders list</option>
<option value="31">31.Store order</option>
<option value="32">32.Get loyalty requests</option>
<option value="33">33.Check status loyalty request</option>
<option value="34">34.Add/Edit tournament</option>
<option value="35">35.Get tournament data</option>
<option value="36">36.Get tournaments list</option>
<option value="37">37.Select/Deselect or Cancel tournament</option>
<option value="38">38.Delete tournament</option>
<option value="39">39.User tournaments history</option>
<option value="40">40.Cancel tournament</option>
<option value="41">41.Tournament widgets</option>
<option value="42">42.Check tournament/bonus promocode validity</option>
<option value="43">43.Get tournament/bonus codes batch list</option>
<option value="44">44.Gnerate tournament/bonus codes</option>
<option value="45">45.Tournament/bonus direct codes save</option>
<option value="46">46.Get Tournament/bonus codes</option>
<option value="47">47.Delete tournament/bonus codes</option>
</select>	
</div>
<div class="table_cell">
<input type="text" name="textapinumber" class="textapinumber" value="" size="75" placeholder="example TID=777/IDUser=55 ..." /> 
</div>	
</div>

</form>
</div>
<hr>
<div class="answer">
</div>
</body>
</html>
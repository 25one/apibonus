<?php
require_once 'SdkBonusApi.php';
$obj=new SdkBonusApi();   

$array_from_platform['numberapi'] = htmlspecialchars($_POST['apinumber']); //numberapi - number api-item (now - immitation (from client), when(real) - from platform)
$array_from_platform['postparamstring'] = htmlspecialchars($_POST['stringpostparam']);; //postparamstring - post-parameters in format TID=777&IDUser=55...
$obj->requestApi($array_from_platform);   

?>

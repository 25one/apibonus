﻿var BaseRecord=(function() {
$(document).ready(function() {
   $("body").on("change", ".selectapinumber", function(){
      $(".textapinumber").attr("value", form_request.selectapinumber.options[form_request.selectapinumber.selectedIndex].id);
      BaseRecord.request(form_request.selectapinumber.options[form_request.selectapinumber.selectedIndex].value, $(".textapinumber").val());
   }); 
   form_request.selectapinumber.options[0].selected=true;
});
return {

   request:function(apinumber, stringpostparam) {  

      var ajaxSetting={
         method:"post",
         url:"controller.php",
         data:"apinumber="+encodeURIComponent(apinumber)+"&stringpostparam="+encodeURIComponent(stringpostparam), 
         success:function(data) {
             $(".answer").html(data);
          }
      };
      $.ajax(ajaxSetting);

   },

};
})();

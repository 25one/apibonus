<?php

$data_answer['response']['addurl'] = $_POST['addurl'];
$data_answer['response']['parameters'] = $_POST['parameters'];
$data_answer_json=json_encode($data_answer);
print_r($data_answer_json);

?>